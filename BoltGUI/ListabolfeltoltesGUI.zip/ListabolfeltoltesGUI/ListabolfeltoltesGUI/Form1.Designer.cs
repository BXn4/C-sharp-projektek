﻿namespace ListabolfeltoltesGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.hanyDB = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.ar = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.megnevezes = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.mennyiseg = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.eladasar = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.eladasnev = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.egyenleg = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hanyDB)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.hanyDB);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.ar);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.megnevezes);
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(239, 359);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Termékek";
            // 
            // hanyDB
            // 
            this.hanyDB.Location = new System.Drawing.Point(146, 325);
            this.hanyDB.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.hanyDB.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.hanyDB.Name = "hanyDB";
            this.hanyDB.Size = new System.Drawing.Size(73, 20);
            this.hanyDB.TabIndex = 6;
            this.hanyDB.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 306);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 39);
            this.button1.TabIndex = 4;
            this.button1.Text = "Megveszem";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(110, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Ár: /db";
            // 
            // ar
            // 
            this.ar.FormattingEnabled = true;
            this.ar.Items.AddRange(new object[] {
            "100",
            "100",
            "100",
            "100",
            "100",
            "100",
            "200",
            "200",
            "200",
            "200",
            "200",
            "200",
            "200",
            "300",
            "300",
            "300",
            "300",
            "500",
            "500",
            "500"});
            this.ar.Location = new System.Drawing.Point(113, 36);
            this.ar.Name = "ar";
            this.ar.Size = new System.Drawing.Size(106, 264);
            this.ar.TabIndex = 2;
            this.ar.SelectedIndexChanged += new System.EventHandler(this.ar_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Megnevezés:";
            // 
            // megnevezes
            // 
            this.megnevezes.FormattingEnabled = true;
            this.megnevezes.Items.AddRange(new object[] {
            "Bab",
            "Krumpli",
            "Kukorica",
            "Görögdinnye",
            "Sárgadinnye",
            "Hagyma",
            "Káposzta",
            "Paprika",
            "Paradicsom",
            "Retek",
            "Répa",
            "Uborka",
            "Borsó",
            "Alma",
            "Eper",
            "Meggy",
            "Cseresznye",
            "Őszibarack",
            "Körte",
            "Banán"});
            this.megnevezes.Location = new System.Drawing.Point(12, 36);
            this.megnevezes.Name = "megnevezes";
            this.megnevezes.Size = new System.Drawing.Size(106, 264);
            this.megnevezes.TabIndex = 0;
            this.megnevezes.SelectedIndexChanged += new System.EventHandler(this.megnevezes_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.mennyiseg);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.eladasar);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.eladasnev);
            this.groupBox2.Location = new System.Drawing.Point(245, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(282, 359);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Termékek";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 306);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(256, 39);
            this.button2.TabIndex = 6;
            this.button2.Text = "Eladom";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(210, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Mennyiség:";
            // 
            // mennyiseg
            // 
            this.mennyiseg.FormattingEnabled = true;
            this.mennyiseg.Items.AddRange(new object[] {
            "10",
            "30"});
            this.mennyiseg.Location = new System.Drawing.Point(213, 36);
            this.mennyiseg.Name = "mennyiseg";
            this.mennyiseg.Size = new System.Drawing.Size(58, 264);
            this.mennyiseg.TabIndex = 4;
            this.mennyiseg.SelectedIndexChanged += new System.EventHandler(this.mennyiseg_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(112, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Ár: /db";
            // 
            // eladasar
            // 
            this.eladasar.FormattingEnabled = true;
            this.eladasar.Items.AddRange(new object[] {
            "100",
            "300"});
            this.eladasar.Location = new System.Drawing.Point(115, 36);
            this.eladasar.Name = "eladasar";
            this.eladasar.Size = new System.Drawing.Size(106, 264);
            this.eladasar.TabIndex = 2;
            this.eladasar.SelectedIndexChanged += new System.EventHandler(this.eladasar_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Megnevezés:";
            // 
            // eladasnev
            // 
            this.eladasnev.FormattingEnabled = true;
            this.eladasnev.Items.AddRange(new object[] {
            "Hagyma",
            "Alma"});
            this.eladasnev.Location = new System.Drawing.Point(12, 36);
            this.eladasnev.Name = "eladasnev";
            this.eladasnev.Size = new System.Drawing.Size(106, 264);
            this.eladasnev.TabIndex = 0;
            this.eladasnev.SelectedIndexChanged += new System.EventHandler(this.eladasnev_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 377);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "Egyenleg:";
            // 
            // egyenleg
            // 
            this.egyenleg.AutoSize = true;
            this.egyenleg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.egyenleg.Location = new System.Drawing.Point(81, 377);
            this.egyenleg.Name = "egyenleg";
            this.egyenleg.Size = new System.Drawing.Size(44, 18);
            this.egyenleg.TabIndex = 6;
            this.egyenleg.Text = "2000";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(146, 309);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Darab:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 406);
            this.Controls.Add(this.egyenleg);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bolt";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hanyDB)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox megnevezes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox ar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox mennyiseg;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox eladasar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox eladasnev;
        private System.Windows.Forms.NumericUpDown hanyDB;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label egyenleg;
        private System.Windows.Forms.Label label7;
    }
}

